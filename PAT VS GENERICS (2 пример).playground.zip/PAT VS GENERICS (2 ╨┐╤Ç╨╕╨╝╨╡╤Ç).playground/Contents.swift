import UIKit

protocol WorkerDescriptorProtocol {
    associatedtype WorkerType
    func describeSpeciality(of type: WorkerType)
}

struct OfficeWorker {
    var fullname: String
    var age: Int
    var speciality: String
}

let bob = OfficeWorker(fullname: "Bob Gray", age: 24, speciality: "I am working in a R.S.O. Industry and occupy a high position")

class OfficeWorkerDescriptor: WorkerDescriptorProtocol {
    
    typealias WorkerType = OfficeWorker
    
    func describeSpeciality(of type: OfficeWorker) {
        print(type.speciality)
    }
}

let officeDescriptor = OfficeWorkerDescriptor()
officeDescriptor.describeSpeciality(of: bob)
