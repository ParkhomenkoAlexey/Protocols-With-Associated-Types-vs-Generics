import UIKit

protocol WorkerDescriptorProtocol {
    func describeSpeciality()
}

struct OfficeWorker: WorkerDescriptorProtocol {
   
    var fullname: String
    var age: Int
    var speciality: String
    
    func describeSpeciality() {
        print(speciality)
    }
}

let bob = OfficeWorker(fullname: "Bob Gray", age: 24, speciality: "I am working in a R.S.O. Industry and occupy a high position")

// generic method
func describeSpeciality<WorkerType: WorkerDescriptorProtocol>(of type: WorkerType) {
    type.describeSpeciality()
}

describeSpeciality(of: bob)
