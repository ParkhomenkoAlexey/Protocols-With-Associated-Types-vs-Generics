import UIKit

protocol Multiplier {
    associatedtype Number
    func multiply(a: Number, b: Number) -> Number
}

class IntMultiplier: Multiplier {
    func multiply(a: Int, b: Int) -> Int {
        return a * b
    }
}

class doubleMultiplier: Multiplier {

    typealias Number = Double
    
    func multiply(a: Double, b: Double) -> Double {
        return a * b
    }
}

let first = IntMultiplier()
first.multiply(a: 5, b: 10)

let second = doubleMultiplier()
second.multiply(a: 3.3, b: 3.3)


